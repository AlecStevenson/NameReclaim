//
//  PhotoView.swift
//  NameReclaim
//
//  Created by alec stevenson on 11/8/22.
//

import SwiftUI

struct Picture: View {
    var body: some View {
        Image("Janitor Named Jim")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 350, height: 250)
            .border(.blue)
    }
}

struct Picture_Previews: PreviewProvider {
    static var previews: some View {
        Picture()
    }
}
